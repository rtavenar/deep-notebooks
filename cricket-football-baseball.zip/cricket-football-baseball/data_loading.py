from PIL import Image
import os
 

def load_data():
    """
    Fonction de chargement des données
    Attention : La librairie pillow doit être installée et s'assurer que le répertoire de travail est celui où se trouve
    la fonction data_loading.py (sans déplacer les sous-dossiers et images)
    """

    labels = []
    images = []

    for dir_files in os.listdir():
        if os.path.isdir(dir_files):
            for img_files in os.listdir('./'+dir_files+'/'):
                if os.path.isfile('./'+dir_files+'/'+img_files):
                    labels.append(dir_files)
                    image = Image.open(dir_files+'/'+img_files)
                    images.append(image)

    return images, labels

print("Lecture des données")
data_images, data_labels = load_data()
print("Données chargées")

