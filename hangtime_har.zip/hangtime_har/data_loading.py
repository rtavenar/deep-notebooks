import csv
import os
import json
 

def load_data():
    """
    Fonction de chargement des données
    Attention : Utilise les librairies csv et json. S'assurer que le répertoire de travail est celui où se trouve
    la fonction data_loading.py (sans déplacer les différents fichiers)
    """

    labels = []
    all_data = {}
    info_obs = {}
    users = []

    print("-- chargement des fichiers csv (observations + labels) --")
    for dir_files in os.listdir():
        if os.path.isfile(dir_files) and dir_files[-3:]=='csv':
            data = []
            label = []
            user_id = dir_files.split('_')[0]
            print("Data ", user_id)
            users.append(user_id)
            with open(dir_files, newline='') as csvfile:
                spamreader = csv.reader(csvfile, delimiter=',', quotechar='\'')
                for i,row in enumerate(spamreader):
                    if i==0:
                        info_obs['observations'] = [row[0]] + row[2:5]
                        info_obs['labels'] = row[5:]
                    else:
                        data.append([[row[0]] + row[2:5]])
                        label.append((row[5],row[6],row[7],row[8]))
                        #print(', '.join(row))
                all_data[user_id] = data
                labels.append(label)

    print("-- chargement du fichier json (meta données) --")
    # Opening JSON file
    f = open('meta.json')
    # returns JSON object as a dictionary
    tmp_meta_data = json.load(f)
    meta_data = {}
    for origin in tmp_meta_data:
        for user_id, user_info in tmp_meta_data[origin].items():
            meta_data[user_id] = user_info
            meta_data[user_id]['origin'] = origin
    # Closing file
    f.close()

    return all_data, labels, info_obs, meta_data

print("Lecture des données")
data_obs, data_labels, info_obs, meta_data = load_data()
print("Données chargées")

print(info_obs)
print(meta_data)
print(len(data_obs))